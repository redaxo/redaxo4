// DE lang variables


tinyMCELang['lang_redaxo_pasteRichtext_title'] = 'Redaxo Formatierten Text einf�gen';
tinyMCELang['lang_redaxo_pasteRichtext_desc'] = 'Formatierten Text einf�gen';
tinyMCELang['lang_redaxo_pasteRichtext_save'] = 'Einf�gen';
tinyMCELang['lang_redaxo_pasteRichtext_cancel'] = 'Abbrechen';
tinyMCELang['lang_redaxo_insertEmail_title'] = 'Redaxo Email Adresse einf�gen';
tinyMCELang['lang_redaxo_insertEmail_desc'] = 'Email Adresse einf�gen';
tinyMCELang['lang_redaxo_insertLink_title'] = 'Redaxo Hyperlink einf�gen';
tinyMCELang['lang_redaxo_insertLink_desc'] = 'Link einf�gen';

