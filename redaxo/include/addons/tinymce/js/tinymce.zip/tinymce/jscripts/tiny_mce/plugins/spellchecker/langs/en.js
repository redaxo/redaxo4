// UK lang variables

tinyMCE.addToLang('spellchecker',{
	desc : 'Toggle spellchecker',
	menu : 'Spellchecker settings',
	ignore_word : 'Ignore word',
	ignore_words : 'Ignore all',
	langs : 'Languages',
	wait : 'Please wait...',
	swait : 'Spellchecking, please wait...',
	sug : 'Suggestions',
	no_sug : 'No suggestions',
	no_mpell : 'No misspellings found.'
});
