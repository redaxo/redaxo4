// UK lang variables

tinyMCELang['lang_redaxo_pasteRichtext_title'] = 'Redaxo Insert formatted text';
tinyMCELang['lang_redaxo_pasteRichtext_desc'] = 'Insert formatted Text';
tinyMCELang['lang_redaxo_pasteRichtext_save'] = 'Insert';
tinyMCELang['lang_redaxo_pasteRichtext_cancel'] = 'Cancel';
tinyMCELang['lang_redaxo_insertEmail_title'] = 'Redaxo Insert email adress';
tinyMCELang['lang_redaxo_insertEmail_desc'] = 'Insert email adress';
tinyMCELang['lang_redaxo_insertLink_title'] = 'Redaxo Insert hyperlink ';
tinyMCELang['lang_redaxo_insertLink_desc'] = 'Insert link';
