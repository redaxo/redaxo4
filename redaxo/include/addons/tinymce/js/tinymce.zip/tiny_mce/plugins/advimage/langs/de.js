// DE lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'Allgemein',
tab_appearance : 'Erscheinungsbild',
tab_advanced : 'Erweitert',
general : 'Allgemein',
title : 'Titel',
preview : 'Vorschau',
constrain_proportions : 'Verh&auml;ltnis beibehalten',
langdir : 'Sprachrichtung',
langcode : 'Sprach-Code',
long_desc : 'Link zu ausf&uuml;hrlicher Beschreibung',
style : 'CSS-Stil',
classes : 'CSS-Klassen',
ltr : 'Von links nach rechts',
rtl : 'Von rechts nach links',
id : 'ID',
image_map : 'Image Map (Bild mit sensitiven Bereichen)',
swap_image : 'Bild austauschen',
alt_image : 'Alternatives Bild',
mouseover : 'f&uuml;r Mouse-Over',
mouseout : 'f&uuml;r Mouse-Out',
misc : 'Sonstiges',
example_img : 'Erscheinungsbild&nbsp;Vorschau&nbsp;Bild',
missing_alt : 'Bitte geben Sie eine sinnvolle Bildbeschreibung ein! \nBenutzer, die einen Textbrowser nutzen oder die Bildanzeige deaktiviert haben, sind auf diese Beschreibung angewiesen (Barrierefreiheit).'
});
