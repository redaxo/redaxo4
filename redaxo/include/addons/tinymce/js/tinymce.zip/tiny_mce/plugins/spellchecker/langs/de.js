// DE lang variables

tinyMCE.addToLang('spellchecker',{
	desc : 'Rechtschreibprüfung ein-/ausschalten',
	menu : 'Einstellungen der Rechtschreibprüfung',
	ignore_word : 'Wort ingorieren',
	ignore_words : 'Alle ignorieren',
	langs : 'Sprachen',
	wait : 'Bitte warten...',
	swait : 'Rechtschreibprüfung, bitte warten...',
	sug : 'Vorschläge',
	no_sug : 'Keine Vorschläge',
	no_mpell : 'Keinen Rechtschreibfehler gefunden.'
});
