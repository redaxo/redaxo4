/* redaxo plugins by vscope new media */

tinyMCE.importPluginLanguagePack('redaxo', 'de,en');

var TinyMCE_redaxoPlugin = {
  getInfo : function() {
    return {
      longname : 'redaxo',
      author : 'vscope new media',
      authorurl : 'http://www.vscope.at',
      infourl : 'http://www.vscope.at',
      version : tinyMCE.majorVersion + "." + tinyMCE.minorVersion
    };
  },
  getControlHTML : function(cn) {
    switch (cn) {
      case "linkHack":
        return tinyMCE.getButtonHTML(cn, 'lang_redaxo_insertLink_desc', '{$pluginurl}/images/link.gif', 'mceLinkHack');
      case "insertEmail":
        return tinyMCE.getButtonHTML(cn, 'lang_redaxo_insertEmail_desc', '{$pluginurl}/images/insertEmail.gif', 'mceInsertEmail');
    }

    return "";
  },
  execCommand : function(editor_id, element, command, user_interface, value) {
    switch (command) {
      case "mceLinkHack":
      	tinyMCE.settings['insertlink_callback']=false;
        tinyMCE.execCommand("mceLink",editor_id,"http://www.orf.at");
        tinyMCE.settings['insertlink_callback']="insertIntLink";
        return true;
    }
    switch (command) {
      case "mceInsertEmail":
    			var template = new Array();
          template['file'] = '../../plugins/redaxo/insertEmail.htm'; // Relative to theme
          template['width'] = 600;
          template['height'] = 420;
          tinyMCE.openWindow(template, {editor_id : editor_id});
          return true;
    }
    return false;
  }
};

tinyMCE.addPlugin("redaxo", TinyMCE_redaxoPlugin);