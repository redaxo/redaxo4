// DE lang variables
tinyMCELang['lang_redaxo_insertEmail_title'] = 'Email Adresse als Link einf�gen';
tinyMCELang['lang_redaxo_insertEmail_desc'] = 'Email Adresse als Link einf�gen';
tinyMCELang['lang_redaxo_insertMedia_title'] = 'Datei als Link einf�gen';
tinyMCELang['lang_redaxo_insertMedia_title'] = 'Datei als Link einf�gen';

