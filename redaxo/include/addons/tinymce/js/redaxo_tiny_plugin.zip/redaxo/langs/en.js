// UK lang variables

tinyMCELang['lang_redaxo_insertEmail_title'] = 'Insert email as link';
tinyMCELang['lang_redaxo_insertEmail_desc'] = 'Insert email as link';
tinyMCELang['lang_redaxo_insertMedia_title'] = 'Insert file as link';
tinyMCELang['lang_redaxo_insertEmail_click'] = 'Insert';
tinyMCELang['lang_redaxo_insertEmail_close'] = 'Cancel';