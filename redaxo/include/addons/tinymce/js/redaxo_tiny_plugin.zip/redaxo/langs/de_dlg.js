tinyMCE.addI18n('de.redaxo_dlg',{
insert_media:"Email Adresse als Link einf\u00FCgen",
insert_email:"Datei als Link einf\u00FCgen"
});