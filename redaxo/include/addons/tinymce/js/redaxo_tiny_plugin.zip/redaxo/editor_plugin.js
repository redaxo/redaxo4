(function() {
  // Load plugin specific language pack
  tinymce.PluginManager.requireLangPack('redaxo');

  tinymce.create('tinymce.plugins.RedaxoPlugin', {
    /**
     * Initializes the plugin, this will be executed after the plugin has been created.
     * This call is done before the editor instance has finished it's initialization so use the onInit event
     * of the editor instance to intercept that event.
     *
     * @param {tinymce.Editor} ed Editor instance that the plugin is initialized in.
     * @param {string} url Absolute URL to where the plugin is located.
     */
    init : function(ed, url) {
      // Register the command so that it can be invoked by using tinyMCE.activeEditor.execCommand('mceExample');
      ed.addCommand('mceInsertMedia', function() {
        ed.windowManager.open({
          file : '../../../../../../../redaxo/index.php?page=medienpool&opener_input_field=TINY',
          width : 600 + ed.getLang('redaxo.delta_width', 0),
          height : 400 + ed.getLang('redaxo.delta_height', 0),
          inline : 1
        });
      });
      
      ed.addCommand('mceInsertEmail', function() {
        ed.windowManager.open({
          file : url + '/insertEmail.htm',
          width : 600 + ed.getLang('redaxo.delta_width', 0),
          height : 300 + ed.getLang('redaxo.delta_height', 0),
          inline : 1
        });
      });

      // register buttons
      ed.addButton('redaxo_insert_media', {
        title : 'redaxo.insert_media',
        cmd : 'mceInsertMedia',
        image : url + '/images/insertfile.gif'
      });
      
      ed.addButton('redaxo_insert_email', {
        title : 'redaxo.insert_email',
        cmd : 'mceInsertEmail',
        image : url + '/images/insertEmail.gif'
      });
    },

    /**
     * Returns information about the plugin as a name/value array.
     * The current keys are longname, author, authorurl, infourl and version.
     *
     * @return {Object} Name/value array containing information about the plugin.
     */
    getInfo : function() {
      return {
        longname : 'Redaxo',
        author : 'vscope, kills',
        authorurl : 'http://www.vscope.at',
        infourl : 'http://www.vscope.at',
        version : tinyMCE.majorVersion + "." + tinyMCE.minorVersion
      };
    }
  });

  // Register plugin
  tinymce.PluginManager.add('redaxo', tinymce.plugins.RedaxoPlugin);
})();


/*

ALTE V2 Version:

tinyMCE.importPluginLanguagePack('redaxo', 'en,de');

var TinyMCE_RedaxoPlugin = {
  getInfo : function() {
    return {
      longname : 'Redaxo',
      author : 'vscope, kills',
      authorurl : 'http://www.vscope.at',
      infourl : 'http://www.vscope.at',
      version : tinyMCE.majorVersion + "." + tinyMCE.minorVersion
    };
  },

  getControlHTML : function(cn) {
    switch (cn) {
      case "insertMedia":
        return tinyMCE.getButtonHTML(cn, 'lang_redaxo_insertMedia_title', '{$pluginurl}/images/insertfile.gif', 'mceInsertMedia', false);
      case "insertEmail":
        return tinyMCE.getButtonHTML(cn, 'lang_redaxo_insertEmail_title', '{$pluginurl}/images/insertEmail.gif', 'mceInsertEmail', false);
    }

    return "";
  },

  execCommand : function(editor_id, element, command, user_interface, value) {
    var inst = tinyMCE.getInstanceById(editor_id), h;

    switch (command) {
      case "mceInsertMedia":
  			var template = new Array();

  			template['file'] = '../../../../../../../redaxo/index.php?page=medienpool&opener_input_field=TINY'; // Relative to theme
  			template['width'] = 600;
  			template['height'] = 400;

  			tinyMCE.openWindow(template, {editor_id : editor_id, scrollbars : 'yes'});

  			return true;

  		case "mceInsertEmail":
  			var template = new Array();

  			template['file'] = '../../plugins/redaxo/insertEmail.htm'; // Relative to theme
  			template['width'] = 600;
  			template['height'] = 300;

  			tinyMCE.openWindow(template, {editor_id : editor_id});

  			return true;
    }

    return false;
  }

};

tinyMCE.addPlugin("redaxo", TinyMCE_RedaxoPlugin);
*/