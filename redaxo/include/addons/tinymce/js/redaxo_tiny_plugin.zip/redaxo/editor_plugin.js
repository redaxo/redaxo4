tinyMCE.importPluginLanguagePack('redaxo', 'en,de');

var TinyMCE_RedaxoPlugin = {
  getInfo : function() {
    return {
      longname : 'Redaxo',
      author : 'vscope, kills',
      authorurl : 'http://www.vscope.at',
      infourl : 'http://www.vscope.at',
      version : tinyMCE.majorVersion + "." + tinyMCE.minorVersion
    };
  },

  getControlHTML : function(cn) {
    switch (cn) {
      case "insertMedia":
        return tinyMCE.getButtonHTML(cn, 'lang_redaxo_insertMedia_title', '{$pluginurl}/images/insertfile.gif', 'mceInsertMedia', false);
      case "insertEmail":
        return tinyMCE.getButtonHTML(cn, 'lang_redaxo_insertEmail_title', '{$pluginurl}/images/insertEmail.gif', 'mceInsertEmail', false);
    }

    return "";
  },

  execCommand : function(editor_id, element, command, user_interface, value) {
    var inst = tinyMCE.getInstanceById(editor_id), h;

    switch (command) {
      case "mceInsertMedia":
  			var template = new Array();

  			template['file'] = '../../../../../../../redaxo/index.php?page=medienpool&opener_input_field=TINY'; // Relative to theme
  			template['width'] = 600;
  			template['height'] = 400;

  			tinyMCE.openWindow(template, {editor_id : editor_id, scrollbars : 'yes'});

  			return true;

  		case "mceInsertEmail":
  			var template = new Array();

  			template['file'] = '../../plugins/redaxo/insertEmail.htm'; // Relative to theme
  			template['width'] = 600;
  			template['height'] = 300;

  			tinyMCE.openWindow(template, {editor_id : editor_id, scrollbars : 'yes'});

  			return true;
    }

    return false;
  }

};

tinyMCE.addPlugin("redaxo", TinyMCE_RedaxoPlugin);